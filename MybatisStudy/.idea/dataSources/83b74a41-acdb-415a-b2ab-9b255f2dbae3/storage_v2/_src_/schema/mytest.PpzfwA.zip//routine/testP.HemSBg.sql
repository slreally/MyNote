create
    definer = root@localhost procedure testP()
begin
    select * from employees;
end;

